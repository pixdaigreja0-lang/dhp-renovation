// Dynamic XML sitemap, available at /sitemap.xml after the Vercel rewrite.
// Configure SITE_URL=https://YOUR-PRODUCTION-DOMAIN in Vercel to make canonical URLs stable.
const paths=[
  '/', '/about/', '/contact/', '/projects/', '/privacy/',
  '/services/carpentry/', '/services/deck-construction/', '/services/deck-repair/',
  '/services/exterior-painting/', '/services/fence-installation-repair/',
  '/services/interior-painting/', '/services/pergola-construction/',
  '/services/porch-construction/', '/services/stair-construction-repair/'
];
const escapeXml=x=>String(x).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export default function handler(req,res){
 if(req.method!=='GET')return res.status(405).send('Method not allowed.');
 const configured=process.env.SITE_URL?.trim().replace(/\/+$/,'');
 const host=(req.headers.host||'').toLowerCase();
 // For preview URLs, output remains test-only. Submit only the final production URL to Google.
 const base=(configured&&/^https:\/\/[\w.-]+(?::\d+)?$/.test(configured))?configured:(/^([\w.-]+)(?::\d+)?$/.test(host)?`https://${host}`:'');
 if(!base)return res.status(503).send('Sitemap requires a production hostname.');
 const urls=paths.map(path=>`  <url><loc>${escapeXml(base+path)}</loc></url>`).join('\n');
 res.setHeader('Content-Type','application/xml; charset=utf-8');
 res.setHeader('Cache-Control','public, max-age=3600');
 return res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`);
}
