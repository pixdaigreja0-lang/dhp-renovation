// DHP Renovation estimate form: standalone Vercel Node.js Function.
// Configure RESEND_API_KEY and ESTIMATE_FROM_EMAIL on the Vercel project.
// Never expose secrets or recipient routing in frontend JavaScript.
const TO_EMAIL = 'Dhprenovation@gmail.com';
const FIELDS = [
  ['name','Full name',120,true],
  ['phone','Phone number',50,true],
  ['email','Email address',254,true],
  ['address','Project address',300,true],
  ['service','Type of service',120,true],
  ['urgency','Project urgency',100,true],
  ['details','Project details',2500,false]
];
const clear = (value) => typeof value === 'string' ? value.trim().replace(/[\x00-\x1f\x7f]/g,' ') : '';
const validEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
const errorResponse = (status, error) => ({status,body:{ok:false,error}});
const unavailable = 'Online estimates are temporarily unavailable. Please call DHP Renovation at (854) 214-0687.';

async function readBody(req){
  if(req.body && typeof req.body === 'object') return req.body;
  if(typeof req.body === 'string') return JSON.parse(req.body);
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk));
    if(Buffer.concat(chunks).length>12000) throw new Error('too large');
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
async function processEstimate(req){
  if(req.method!=='POST') return errorResponse(405,'Method not allowed.');
  if(Number(req.headers['content-length']||0)>12000) return errorResponse(413,'Request is too large.');
  let data;
  try {data = await readBody(req);}catch{return errorResponse(400,'Please check the form details and try again.');}
  if(!data || typeof data!=='object' || Array.isArray(data)) return errorResponse(400,'Please check the form details and try again.');
  // Invisible honeypot, for basic bot reduction.
  if(clear(data.website)) return {status:200,body:{ok:true}};
  const lead={};
  for(const [key,label,max,required] of FIELDS){
    const value=clear(data[key]);
    if((required&&!value)||value.length>max) return errorResponse(400,`Please check the ${label.toLowerCase()} field.`);
    lead[key]=value;
  }
  if(!validEmail(lead.email)) return errorResponse(400,'Please enter a valid email address.');

  const {RESEND_API_KEY,ESTIMATE_FROM_EMAIL}=process.env;
  if(!RESEND_API_KEY||!ESTIMATE_FROM_EMAIL||!validEmail(ESTIMATE_FROM_EMAIL.match(/<([^>]+)>/)?.[1] || ESTIMATE_FROM_EMAIL)){
    console.error('DHP estimate endpoint is not configured.');
    return errorResponse(503,unavailable);
  }
  const details = FIELDS.map(([key,label])=>`${label}: ${lead[key]||'Not provided'}`).join('\n');
  try {
    const provider=await fetch('https://api.resend.com/emails',{
      method:'POST',
      headers:{'Authorization':`Bearer ${RESEND_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({
        from:ESTIMATE_FROM_EMAIL,
        to:[TO_EMAIL],
        reply_to:lead.email,
        subject:`DHP Renovation estimate request — ${lead.service.slice(0,70)}`,
        text:`New DHP Renovation estimate request\n\n${details}\n\nReply to this message to contact the homeowner.`
      }),
      signal:AbortSignal.timeout(12000)
    });
    if(!provider.ok){
      console.error('Email provider rejected estimate request with HTTP',provider.status);
      return errorResponse(502,'We could not send your request right now. Please call (854) 214-0687.');
    }
    const result=await provider.json().catch(()=>({}));
    if(!result.id) return errorResponse(502,'We could not confirm the email was accepted. Please call (854) 214-0687.');
    return {status:200,body:{ok:true,message:'Your estimate request has been accepted for delivery to DHP Renovation.'}};
  }catch(err){
    console.error('Email delivery service unavailable:',err?.name||'unknown error');
    return errorResponse(502,'Your request could not be sent. Please call (854) 214-0687.');
  }
}

// Vercel Node.js runtime requires a default export in /api/*.mjs.
export default async function handler(req,res){
  res.setHeader('Content-Type','application/json; charset=utf-8');
  res.setHeader('Cache-Control','no-store');
  try {
    const {status,body}=await processEstimate(req);
    res.status(status).json(body);
  }catch(error){
    console.error('Unexpected estimate endpoint error',error?.name||'unknown error');
    res.status(500).json({ok:false,error:unavailable});
  }
}
