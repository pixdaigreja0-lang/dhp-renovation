(()=>{
const v=document.querySelector('.dhp-review-viewport'),t=document.getElementById('google-reviews-track'),dots=document.getElementById('google-reviews-dots'),prev=document.querySelector('[data-review-prev]'),next=document.querySelector('[data-review-next]');
if(!v||!t||!dots||!prev||!next)return;
const cards=[...t.querySelectorAll('.dhp-review-item')];if(!cards.length)return;
function range(){return Math.max(0,v.scrollWidth-v.clientWidth)}
function step(){const el=cards[0];return el.getBoundingClientRect().width+(parseFloat(getComputedStyle(t).gap)||18)}
function pages(){return Math.max(1,Math.ceil(range()/step())+1)}
function update(){const curr=Math.min(pages()-1,Math.round(v.scrollLeft/step()));dots.replaceChildren();for(let i=0;i<pages();i++){const b=document.createElement('button');b.type='button';b.className='dhp-review-dot';b.setAttribute('aria-label','Go to review '+(i+1));b.setAttribute('aria-current',String(i===curr));b.addEventListener('click',()=>v.scrollTo({left:Math.min(range(),i*step()),behavior:'smooth'}));dots.append(b)}prev.disabled=v.scrollLeft<2;next.disabled=v.scrollLeft>=range()-2;}
function move(dir){v.scrollBy({left:dir*step(),behavior:'smooth'})}
prev.addEventListener('click',()=>move(-1));next.addEventListener('click',()=>move(1));v.addEventListener('scroll',()=>requestAnimationFrame(update),{passive:true});v.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();move(e.key==='ArrowRight'?1:-1)}});window.addEventListener('resize',update);update();
})();
