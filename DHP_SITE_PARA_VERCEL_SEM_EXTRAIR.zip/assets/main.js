(()=>{
  const q = s => document.querySelector(s);

  const menu = q('.menu-toggle');
  const links = q('#primary-nav');
  if(menu && links){
    menu.addEventListener('click',()=>{
      const open = links.classList.toggle('show');
      menu.setAttribute('aria-expanded', String(open));
      menu.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
  }

  const drop = q('.dropdown-button');
  if(drop){
    const d = drop.closest('.dropdown');
    const setDropdown = open => {
      d.classList.toggle('open', open);
      drop.setAttribute('aria-expanded', String(open));
    };
    drop.addEventListener('click',()=>setDropdown(!d.classList.contains('open')));
    document.addEventListener('click',event=>{
      if(!d.contains(event.target))setDropdown(false);
    });
    document.addEventListener('keydown',event=>{
      if(event.key==='Escape'&&d.classList.contains('open')){
        setDropdown(false);
        drop.focus();
      }
    });
  }

  document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{
    document.querySelectorAll('.filter').forEach(b=>{
      const active=b===btn;
      b.classList.toggle('active', active);
      b.setAttribute('aria-pressed', String(active));
    });
    document.querySelectorAll('.gallery-all figure').forEach(f=>{
      f.classList.toggle('hidden', btn.dataset.filter !== 'all' && f.dataset.category !== btn.dataset.filter);
    });
  }));

  const y = q('#year');
  if(y) y.textContent = String(new Date().getFullYear());

  const form=q('#estimate-form'), status=q('#form-status');
  if(form){
    const submit=form.querySelector('button[type="submit"]');
    form.addEventListener('submit',async e=>{
      e.preventDefault();
      if(!form.reportValidity()) return;
      if(location.protocol!=='http:' && location.protocol!=='https:'){
        if(status) status.textContent='To send an estimate, use the published website. The downloaded preview cannot send emails. Call (854) 214-0687 for now.';
        return;
      }
      if(submit) submit.disabled=true;
      if(status) status.textContent='Sending your estimate request…';
      const original=submit?.textContent;
      try{
        const data=Object.fromEntries(new FormData(form).entries());
        const response=await fetch('/api/estimate',{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify(data)
        });
        const result=await response.json().catch(()=>({}));
        if(!response.ok || !result.ok) throw new Error(result.error || 'Unable to send this request. Please call (854) 214-0687.');
        if(status) status.textContent='Thank you! Your estimate request has been sent to DHP Renovation. We will review your project details.';
        form.reset();
      }catch(error){
        if(status) status.textContent=error?.message || 'Unable to send. Please call (854) 214-0687.';
      }finally{
        if(submit) submit.disabled=false;
      }
    });
  }

  const reviewTrack = q('.v5-review-track');
  const prev = q('.v5-carousel-prev');
  const next = q('.v5-carousel-next');
  if(reviewTrack && prev && next){
    const step = ()=> {
      const card = reviewTrack.querySelector('.v5-review-card');
      return (card ? card.getBoundingClientRect().width : 340) + 18;
    };
    prev.addEventListener('click',()=> reviewTrack.scrollBy({left:-step(), behavior:'smooth'}));
    next.addEventListener('click',()=> reviewTrack.scrollBy({left: step(), behavior:'smooth'}));
  }
})();
