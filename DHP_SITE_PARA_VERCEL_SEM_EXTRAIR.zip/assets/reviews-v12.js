(()=>{
  const viewport=document.querySelector('.dhp-review-viewport');
  const track=document.getElementById('google-reviews-track');
  const dots=document.getElementById('google-reviews-dots');
  const prev=document.querySelector('[data-review-prev]');
  const next=document.querySelector('[data-review-next]');
  const wrapper=document.getElementById('google-reviews-carousel');
  const pending=document.getElementById('google-reviews-pending');
  if(!viewport||!track||!dots||!prev||!next||!wrapper||!pending)return;
  const make=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=String(txt);return n};
  const cleanStars=(rating)=>{const names={ONE:1,TWO:2,THREE:3,FOUR:4,FIVE:5};return Math.min(5,Math.max(0,Math.round(names[rating]||Number(rating)||0)))};
  const reviewsCards=()=>Array.from(track.querySelectorAll('.dhp-review-item'));
  let scrollPending=false;
  function update(){
    const cards=reviewsCards(); if(!cards.length)return;
    const first=cards[0];
    const gap=parseFloat(getComputedStyle(track).gap)||18;
    const step=first.getBoundingClientRect().width+gap;
    const visible=Math.max(1,Math.round((viewport.clientWidth+gap)/step));
    const pages=Math.max(1,Math.ceil(cards.length/visible));
    const page=Math.max(0,Math.min(pages-1,Math.round(viewport.scrollLeft/(step*visible))));
    dots.replaceChildren();
    for(let i=0;i<pages;i++){
      const d=make('button','dhp-review-dot'); d.type='button';
      d.setAttribute('aria-label',`Go to review page ${i+1}`);
      d.setAttribute('aria-current',String(i===page));
      d.onclick=()=>viewport.scrollTo({left:Math.min(i*visible*step,viewport.scrollWidth-viewport.clientWidth),behavior:'smooth'});
      dots.append(d);
    }
    prev.disabled=viewport.scrollLeft<=2;
    next.disabled=viewport.scrollLeft+viewport.clientWidth>=viewport.scrollWidth-2;
  }
  function move(direction){
    const cards=reviewsCards(); if(!cards.length)return;
    const gap=parseFloat(getComputedStyle(track).gap)||18;
    const step=cards[0].getBoundingClientRect().width+gap;
    const visible=Math.max(1,Math.round((viewport.clientWidth+gap)/step));
    const left=direction>0?Math.min(viewport.scrollWidth-viewport.clientWidth,viewport.scrollLeft+visible*step):Math.max(0,viewport.scrollLeft-visible*step);
    viewport.scrollTo({left,behavior:'smooth'});
  }
  prev.onclick=()=>move(-1);next.onclick=()=>move(1);
  viewport.addEventListener('scroll',()=>{if(scrollPending)return;scrollPending=true;requestAnimationFrame(()=>{scrollPending=false;update()})},{passive:true});
  viewport.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();move(1)}if(e.key==='ArrowLeft'){e.preventDefault();move(-1)}});
  window.addEventListener('resize',update);
  function render(data){
    if(!data||data.source!=='Google Business Profile'||data.verified!==true||!Array.isArray(data.reviews)||!data.reviews.length)return;
    track.replaceChildren();
    for(const r of data.reviews){
      if(!r)continue;
      const card=make('article','dhp-review-item');
      const head=make('header');
      const avatar=make('span','dhp-customer-avatar');
      const name=String(r.reviewer?.displayName||r.authorName||'Google reviewer');
      if(r.reviewer?.profilePhotoUrl){
        const img=document.createElement('img');img.src=r.reviewer.profilePhotoUrl;img.alt=`${name} profile photo`;img.loading='lazy';img.referrerPolicy='no-referrer';img.onerror=()=>{img.remove();avatar.textContent=name.substring(0,1).toUpperCase()};avatar.append(img);
      }else avatar.textContent=name.substring(0,1).toUpperCase();
      const person=make('div');person.append(make('strong','',name));
      const stars=make('div','dhp-star','★'.repeat(cleanStars(r.starRating||r.rating)));stars.setAttribute('aria-label',`${cleanStars(r.starRating||r.rating)} stars`);person.append(stars);
      if(r.createTime){const dt=new Date(r.createTime);if(!isNaN(dt))person.append(make('small','',dt.toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'})))}
      head.append(avatar,person);card.append(head,make('p','dhp-review-copy',String(r.comment||'Rating only — no written comment.')));track.append(card);
    }
    if(!track.children.length)return;
    pending.hidden=true;wrapper.hidden=false;
    const avg=document.getElementById('google-review-average');const count=document.getElementById('google-review-count');
    if(avg&&data.rating!==null&&Number.isFinite(Number(data.rating)))avg.textContent=Number(data.rating).toFixed(1);const starBanner=document.querySelector('.dhp-review-rating .dhp-star');if(starBanner)starBanner.hidden=false;
    if(count)count.textContent=`${Number.isInteger(data.totalReviewCount)?data.totalReviewCount:track.children.length} Google reviews`;
    requestAnimationFrame(update);
  }
  fetch('/assets/google-reviews.json',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(render).catch(()=>{});
})();